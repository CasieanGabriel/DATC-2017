﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlbumPhoto.Models
{
    public class AddCommentModel
    {

        public string FileName { get; set; }

        public string FilePartitionKey { get; set; }
        public string ThumbnailUrl { get; set; }

        public IList<string> CommentsToPhoto { get; set; }
        public string Comment { get; set; }
    }
}