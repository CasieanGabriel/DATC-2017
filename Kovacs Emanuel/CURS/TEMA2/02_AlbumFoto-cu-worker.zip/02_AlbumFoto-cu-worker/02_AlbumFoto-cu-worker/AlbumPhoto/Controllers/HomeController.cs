﻿using AlbumPhoto.Models;
using AlbumPhoto.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AlbumPhoto.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            var service = new AlbumFotoService();
            return View(service.GetPoze());
        }

        [HttpPost]
        public ActionResult IncarcaPoza(HttpPostedFileBase file)
        {
            var service = new AlbumFotoService();
            if (file!=null && file.ContentLength > 0)
            {
                service.IncarcaPoza("guest", file.FileName, file.InputStream);
            }

            return View("Index", service.GetPoze());
        }

        public ActionResult AddComment(string fileName, string filePartitionKey)
        {
            var service = new AlbumFotoService();
            var file = service.GetPoze().Single(x => x.RowKey == fileName);

            var commentModel = new AddCommentModel
            {
                FileName = fileName,
                FilePartitionKey = filePartitionKey,
                ThumbnailUrl = file.ThumbnailUrl,
                CommentsToPhoto = file.CommentsToPhoto
            };

            return View(commentModel);
        }

        [HttpPost]

        public ActionResult AddComment(AddCommentModel commentModel)
        {
            var service = new AlbumFotoService();
            service.AddComment(commentModel.FileName, commentModel.FilePartitionKey, commentModel.Comment);
            return RedirectToAction("AddComment", new { fileName = commentModel.FileName, filePartitionKey = commentModel.FilePartitionKey });
        }

        public ViewResult GenerateLink(string fileName)
        {
            var service = new AlbumFotoService();
            var resultLink = service.GetUrl(fileName);
            return View("GenerateLink", model: resultLink);
        }
    }
}
