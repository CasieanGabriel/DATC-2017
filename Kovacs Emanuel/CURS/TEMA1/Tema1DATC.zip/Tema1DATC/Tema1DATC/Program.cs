﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using Tema1DATC.RequestHandler;
using Tema1DATC.Constants;
using Tema1DATC.Model;

namespace Tema1DATC
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Info");
            Console.WriteLine();

            IRequestHandler httpClientRequestHandler = new HttpClientRequestHandler();
            var data = GetBreweries(httpClientRequestHandler);

            //Console.WriteLine(data);
            var o = data;

            RootObjectBeer rootObjectBeer = new RootObjectBeer();
            foreach(JObject dat in data)
            {
                Console.WriteLine("Berarie: {0}", dat.GetValue("_links"));
                var link = "["+dat.GetValue("_links")+"]";
                var href = JArray.Parse(link);
                foreach(JObject jobj in href)
                {
                    Console.WriteLine("Este: {0} \n", jobj.GetValue("brewery"));
                    var li = (string)jobj.GetValue("brewery");//JArray
                    var hre = JArray.Parse(li);
                    /*foreach (JObject job in hre)
                    {
                        Console.WriteLine("Este aici: {0} \n", job.GetValue("href"));
                    }*/
                }
            }
            /*Console.WriteLine();
            Console.WriteLine("Berarii");
            Console.WriteLine("\ngggggggggg"+data.Children());
            Console.WriteLine("igigigigigigiigiggigigigi/: {0}", data.Children().Values());
            /*foreach(object k in data.Children())
            {
                Console.WriteLine("OBJ: {0}", k.ToString());
                foreach (object i in data.Children().Children<JToken>())
                {
                    Console.WriteLine("hhhhhhhhhh: {0}", data.Children().GetEnumerator());
                }*/
           /// }*/
            /*foreach(JObject obj in data)
            {
                Console.WriteLine("Berarie: {0}", obj.GetValue("ResourceList"));
                var obj1 = obj.GetValue("_links");
                Console.WriteLine("\nmmmmmmmmmmm: {0}", obj1.GetType());
            }*/
            //Console.WriteLine("Alegegi Pagina");

           /* foreach(JObject dat in data)
            {
                Console.Write("xxx: {0}\n", dat.GetValue("_embedded"));
                o = dat.GetValue("_embedded");
                //Console.WriteLine("{0}",dat.GetValue("_breweries")); 
            }*/

            /*foreach(object i in data)
            {
                Console.Write("mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm: {0}\n", i);
            }*/
            /*foreach(JProperty da in o)
            {
                Console.WriteLine("ddddddd: {0}", da.Value);
                foreach (JProperty d in da.Value)
                {
                    Console.WriteLine("ssssssssssssssss: {0}", d.Value);

                }
            }*/
            /*foreach(JObject dat in data.Children())
            {
                Console.WriteLine("Total results: {0}\n", dat.GetValue("_embedded"));
                Console.WriteLine();
               
            }*/

            //Console.WriteLine();
            Console.ReadLine();
        }

        private static Func<JToken, IEnumerable<object>> write(JToken data)
        {
            throw new NotImplementedException();
        }

        public static JToken GetBreweries(IRequestHandler requestHandler)
        {
            return requestHandler.GetBreweries(RequestConstants.CalculateURL(0,1));
        }
    }
}
