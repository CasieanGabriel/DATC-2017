﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
//using System.Net.Http.HttpClient.Deserializers;
namespace Tema1DATC.Model
{
    public class ResourceList
    {
        [JsonProperty("Id")]
        public int Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("_links")]
        public List<object> Links { get; set; }
    }
}
