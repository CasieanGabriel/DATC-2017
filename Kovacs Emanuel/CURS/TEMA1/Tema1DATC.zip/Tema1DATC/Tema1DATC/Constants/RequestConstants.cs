﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema1DATC.Constants
{
    public static class RequestConstants
    {
        public static string Url = "http://datc-rest.azurewebsites.net/breweries";
        public static string CalculateURL(int id,int b)
        {
            string url = null;
            if(id==0)
            {
                url = Url;
            }
            else if (id == 1)
            {
                url = Url+"/"+b.ToString()+"/beers";
            }
            
            return url;
        }
    }
}
