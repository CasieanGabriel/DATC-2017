import React from 'react';
import { render } from 'react-dom';
import AppPage from './components/appPage.js';

render (
    <div>
            <AppPage />
    </div>,
    document.getElementById("app")
)